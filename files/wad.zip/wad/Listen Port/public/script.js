function showAlert() {
    alert("Alert Button is Clicked")
}