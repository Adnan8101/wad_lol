document.getElementById('login-form').addEventListener('submit', async function (e) {
    e.preventDefault(); // Prevent form from submitting automatically
    
    let errors = [];
  
    // Get values from the form
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();
  
    // Validate username
    if (username === '') {
      errors.push('Username is required.');
    }
  
    // Validate password (at least 6 characters)
    if (password.length < 6) {
      errors.push('Password must be at least 6 characters long.');
    }
  
    // Display error messages or submit the form
    const errorDiv = document.getElementById('error-messages');
    if (errors.length > 0) {
      errorDiv.innerHTML = errors.join('<br>');
    } else {
      errorDiv.innerHTML = ''; // Clear previous errors
  
      // Send data to server using POST request
      const response = await fetch('/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
  
      if (response.ok) {
        alert('Login successful!');
      } else {
        alert('Login failed!');
      }
    }
  });
  