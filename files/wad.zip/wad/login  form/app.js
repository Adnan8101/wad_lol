const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();

// Middleware to parse JSON request bodies
app.use(bodyParser.json());

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Handle login form submission and log data to the console
app.post('/login', (req, res) => {
  const { username, password } = req.body;

  // Log the data to the live console
  console.log('Login Data:', { username, password });

  // Send a success response back to the frontend
  res.status(200).json({ message: 'Login data received and logged.' });
});

// Start the server
const port = 3000;
app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
