document.addEventListener('DOMContentLoaded', function () {
    const userForm = document.getElementById('user-form');
    const usersList = document.getElementById('users-list');
    const submitBtn = document.getElementById('submit-btn');
    const cancelBtn = document.getElementById('cancel-btn');
    let editMode = false;
    let editUserId = null;
  
    // Fetch and display all users
    function fetchUsers() {
      fetch('/users')
        .then(res => res.json())
        .then(users => {
          usersList.innerHTML = '';
          users.forEach(user => {
            const li = document.createElement('li');
            li.innerHTML = `
              ${user.username} - ${user.email} 
              <button onclick="editUser(${user.id}, '${user.username}', '${user.email}')">Edit</button>
              <button onclick="deleteUser(${user.id})">Delete</button>
            `;
            usersList.appendChild(li);
          });
        });
    }
  
    // Add a new user or update existing user
    userForm.addEventListener('submit', function (e) {
      e.preventDefault();
      
      const formData = new FormData(userForm);
      const userData = {
        username: formData.get('username'),
        email: formData.get('email'),
        password: formData.get('password'),
      };
  
      if (editMode) {
        // Update user
        fetch(`/users/${editUserId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(userData),
        })
          .then(res => res.json())
          .then(data => {
            fetchUsers();
            resetForm();
          });
      } else {
        // Add user
        fetch('/users', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(userData),
        })
          .then(res => res.json())
          .then(data => {
            fetchUsers(); // Refresh the list of users
            userForm.reset(); // Clear the form
          });
      }
    });
  
    // Reset form
    function resetForm() {
      editMode = false;
      editUserId = null;
      submitBtn.innerText = 'Add User';
      cancelBtn.classList.add('hidden');
      userForm.reset();
    }
  
    // Edit user
    window.editUser = function (id, username, email) {
      editMode = true;
      editUserId = id;
      document.getElementById('username').value = username;
      document.getElementById('email').value = email;
      submitBtn.innerText = 'Update User';
      cancelBtn.classList.remove('hidden');
    };
  
    // Delete user
    window.deleteUser = function (id) {
      fetch(`/users/${id}`, { method: 'DELETE' })
        .then(res => res.json())
        .then(data => {
          fetchUsers(); // Refresh the list of users
        });
    };
  
    // Cancel edit
    cancelBtn.addEventListener('click', resetForm);
  
    // Fetch users on page load
    fetchUsers();
  });
  