const express = require('express');
const path = require('path');

const port = 3000;

const app = express();

app.get('/hello', (req,res) => {
    res.send("Hello World")
})

app.get('/get-json',(req,res) => {
    res.json({message: 'Hello World! ',status: "Sucess"})
})

app.listen(port,() => {
    console.log("Chal gaya server")
})