const express = require('express');
const path = require('path');
const app = express();

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public'))); // Serve static HTML files

// In-memory array to store tasks
let tasks = [];

// Get all tasks (READ)
app.get('/tasks', (req, res) => {
  res.json(tasks);
});

// Get a single task by ID (READ)
app.get('/tasks/:id', (req, res) => {
  const task = tasks.find(t => t.id === parseInt(req.params.id));
  if (!task) return res.status(404).send('Task not found');
  res.json(task);
});

// Add a new task (CREATE)
app.post('/tasks', (req, res) => {
  const task = {
    id: tasks.length + 1,  // Auto-increment ID
    title: req.body.title,
    completed: req.body.completed || false
  };
  tasks.push(task);
  res.status(201).json(task);  // Send back the created task
});

// Update a task by ID (UPDATE)
app.put('/tasks/:id', (req, res) => {
  const task = tasks.find(t => t.id === parseInt(req.params.id));
  if (!task) return res.status(404).send('Task not found');

  task.title = req.body.title || task.title;
  task.completed = req.body.completed !== undefined ? req.body.completed : task.completed;

  res.json(task);
});

// Delete a task by ID (DELETE)
app.delete('/tasks/:id', (req, res) => {
  const taskIndex = tasks.findIndex(t => t.id === parseInt(req.params.id));
  if (taskIndex === -1) return res.status(404).send('Task not found');

  tasks.splice(taskIndex, 1);  // Remove task from array
  res.send('Task deleted successfully');
});

// Start the server
const port = 3000;
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
