const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();

// Middleware to parse JSON request bodies
app.use(bodyParser.json());

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Handle form submission and log data to the console
app.post('/submit-form', (req, res) => {
  const { name, email, password } = req.body;

  // Log the data to the live console
  console.log('Form Data:', { name, email, password });

  // Send a success response back to the frontend
  res.status(200).json({ message: 'Form data received and logged.' });
});

// Start the server
const port = 3000;
app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
