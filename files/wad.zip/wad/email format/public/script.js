document.getElementById('registration-form').addEventListener('submit', async function (e) {
    e.preventDefault(); // Prevent form from submitting automatically
    
    let errors = [];
  
    // Get values from the form
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();
  
    // Validate name
    if (name === '') {
      errors.push('Name is required.');
    }
  
    // Validate email (using a basic email format check)
    const emailPattern = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/;
    if (!emailPattern.test(email)) {
      errors.push('Please enter a valid email address.');
    }
  
    // Validate password (at least 6 characters)
    if (password.length < 6) {
      errors.push('Password must be at least 6 characters long.');
    }
  
    // Display error messages or submit the form
    const errorDiv = document.getElementById('error-messages');
    if (errors.length > 0) {
      errorDiv.innerHTML = errors.join('<br>');
    } else {
      errorDiv.innerHTML = ''; // Clear previous errors
  
      // Send data to server using POST request
      const response = await fetch('/submit-form', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password })
      });
  
      if (response.ok) {
        alert('Form submitted successfully!');
      } else {
        alert('Form submission failed!');
      }
    }
  });
  