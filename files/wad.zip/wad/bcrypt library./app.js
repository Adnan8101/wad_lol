const express = require('express');
const bcrypt = require('bcrypt');
const path = require('path');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Handle password hashing request
app.post('/hash-password', async (req, res) => {
  const { password } = req.body;
  
  if (!password) {
    return res.status(400).json({ message: 'Password is required' });
  }
  
  try {
    const saltRounds = 10;
    const hashedPassword = await bcrypt.hash(password, saltRounds);
    res.json({ hashedPassword });
  } catch (error) {
    res.status(500).json({ message: 'Error hashing password' });
  }
});

// Handle password verification request
app.post('/verify-password', async (req, res) => {
  const { password, hashedPassword } = req.body;

  if (!password || !hashedPassword) {
    return res.status(400).json({ message: 'Both password and hashed password are required' });
  }

  try {
    const match = await bcrypt.compare(password, hashedPassword);
    if (match) {
      res.json({ message: 'Password matches the hashed password!' });
    } else {
      res.status(400).json({ message: 'Password does not match the hashed password' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Error verifying password' });
  }
});

// Start the server
const port = 3000;
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
