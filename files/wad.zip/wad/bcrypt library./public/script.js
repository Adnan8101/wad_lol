// Handle the form submission for hashing the password
document.getElementById('password-form').addEventListener('submit', async function (e) {
    e.preventDefault(); // Prevent the form from reloading the page
  
    const password = document.getElementById('password').value;
    
    if (!password) {
      alert('Please enter a password');
      return;
    }
  
    // Send the password to the server for hashing
    const response = await fetch('/hash-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password })
    });
  
    const data = await response.json();
  
    if (response.ok) {
      document.getElementById('hashed-password').innerText = data.hashedPassword;
    } else {
      document.getElementById('hashed-password').innerText = 'Error: ' + data.message;
    }
  });
  
  // Handle the form submission for verifying the password
  document.getElementById('verify-form').addEventListener('submit', async function (e) {
    e.preventDefault(); // Prevent the form from reloading the page
  
    const plainPassword = document.getElementById('plain-password').value;
    const hashedPassword = document.getElementById('hashed-password-input').value;
  
    if (!plainPassword || !hashedPassword) {
      alert('Please enter both the original and hashed passwords');
      return;
    }
  
    // Send the password and hashed password to the server for verification
    const response = await fetch('/verify-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password: plainPassword, hashedPassword: hashedPassword })
    });
  
    const data = await response.json();
  
    if (response.ok) {
      document.getElementById('verification-result').innerText = data.message;
    } else {
      document.getElementById('verification-result').innerText = 'Error: ' + data.message;
    }
  });
  