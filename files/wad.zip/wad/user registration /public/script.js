document.getElementById('registration-form').addEventListener('submit', async function (e) {
    e.preventDefault(); // Prevent default form submission
  
    let errors = [];
  
    // Get values from the form
    const username = document.getElementById('username').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();
  
    // Validate username
    if (username === '') {
      errors.push('Username is required.');
    }
  
    // Validate email (basic email format check)
    const emailPattern = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/;
    if (!emailPattern.test(email)) {
      errors.push('Please enter a valid email address.');
    }
  
    // Validate password (at least 6 characters)
    if (password.length < 6) {
      errors.push('Password must be at least 6 characters long.');
    }
  
    // Display error messages or submit the form
    const errorDiv = document.getElementById('error-messages');
    if (errors.length > 0) {
      errorDiv.innerHTML = errors.join('<br>');
    } else {
      errorDiv.innerHTML = ''; // Clear errors
  
      // Send data to server
      const response = await fetch('/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, email, password })
      });
  
      if (response.ok) {
        document.getElementById('success-message').innerText = 'Registration successful!';
      } else {
        document.getElementById('success-message').innerText = 'Registration failed.';
      }
    }
  });
  